package Bank.Service;

import java.util.List;

public interface Service {

	void createAccount();

     double showBal( int amt);

     double deposit(int amt1);

     double withdraw(int amt2);

     double fundTrans(int amt3);

     
	List<String> printTrans(int amt4);
	
	



}

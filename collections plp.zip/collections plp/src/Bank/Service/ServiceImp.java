package Bank.Service;
import java.util.List;
import java.util.Scanner;


import Bank.dao.Dao;
import Bank.dao.Daoimp;
import Bank.model.Bank;
import Bank.validations.Validate;

public class ServiceImp  implements Service{
Scanner sc=new Scanner(System.in);
 private Dao d = new Daoimp();

Validate val=new Validate();
Bank b=new Bank();
	@Override
	public void createAccount()
	{
		Bank b=new Bank();
		System.out.println("ENTER ACCOUNT NUMBER");
           int  s=sc.nextInt();
			if(val.num(s))
		     b.setAnum(s);
			else{
				System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
				System.exit(0);
				
			}
		System.out.println("ENTER  NAME");
		 String s1=sc.next();
			if(val.name(s1))
				b.setName(s1);  
			else{
				System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
				System.exit(0);
				
			}
		
		System.out.println("ENTER AMOUNT");
		double  s2=sc.nextInt();
		if(val.num1(s2))
			b.setAmount(s2);
		else{
			System.out.println("PLEASE ENTER A VALID AMOUNT");
			System.exit(0);
		}
		
       d.save1(b);
       	
	}
	
	@Override
	public double showBal(int amt) {
		if(val.num(amt)){
			 b.setAnum(amt);}
		
		else{
			System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
			System.exit(0);
			
		}
			
		return d.showBal1(amt);
	
		
	}

	@Override
	public double deposit(int amt1) {
		
		if(val.num(amt1)){
		     b.setAnum(amt1);}
		else{
			System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
			System.exit(0);
			
		}
			
		System.out.println("ENTER AMOUNT");
		 double an=sc.nextDouble();
		
		if(val.num1(an))
			b.setAmount(an);
		else{
			System.out.println("PLEASE ENTER A VALID AMOUNT");
			System.exit(0);
		}
		
		return d.deposit1(amt1, an);
		
		
	}

	@Override
	public double withdraw(int amt2) {
		
		if(val.num(amt2))
		     b.setAnum(amt2);
		else{
			System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
			System.exit(0);
			
		}
		System.out.println("ENTER AMOUNT");
		double  an1=sc.nextDouble();
	
	if(val.num1(an1))
		b.setAmount(an1);
	else{
		System.out.println("PLEASE ENTER A VALID AMOUNT");
		System.exit(0);
	}
	
		if(b.amount==0)
		{
			System.out.println("SORRY INSUFFICIENT BALANCE");
			System.exit(0);
		}
		return d.withdraw1(amt2,an1);
		
		
	}

	@Override
	public double fundTrans(int amt3) {if(val.num(amt3))
	     b.setAnum(amt3);
		else{
			System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
			System.exit(0);
		}
		System.out.println("ENTER  ANOTHER ACCOUNT NUMBER");
		 int an2=sc.nextInt();
		 if(val.num(an2))
		     b.setAnum(an2);
			else{
				System.out.println("PLEASE ENTER A VALID ACCOUNT NUMBER");
				System.exit(0);
			}
		 
		 System.out.println("ENTER AMOUNT");
		 int an3=sc.nextInt();
		
	if(val.num(an3))
		b.setAmount(an3);
	else{
		System.out.println("PLEASE ENTER A VALID AMOUNT");
		System.exit(0);
	}
	
		if(b.amount==0)
		{
			System.out.println("SORRY INSUFFICIENT BALANCE");
			System.exit(0);
		}
		
		return d.fund1(amt3,an2,an3);
		
		
	}

	@Override
	public List<String> printTrans(int amt4) {
		
		return d.printTrans(amt4);
		
		
	}
}

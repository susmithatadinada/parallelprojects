package Bank.model;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	
	
	
	public String name;
	public  int anum;
	public double amount;	
	public static List<String> l= new ArrayList();
	public List<String>getli(){
		return l;
	}
	public Bank( int i, String name, double amount) {
			this.anum=i;
			this.name=name;
			this.amount=amount;
			
		}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAnum(int amt1) {
		return anum;
	}
	public void setAnum(int anum) {
		this.anum = anum;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double an3) {
		this.amount = an3;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
	
	
	



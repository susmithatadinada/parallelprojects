package Bank.dao;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import Bank.model.Bank;
import java.util.Date;
public class Daoimp implements Dao {
	private static List<Bank> li= new ArrayList();
static{
	Bank b1=new Bank (2133,"susmi",9000.50);
	Bank b2=new Bank (2144,"ruchi",9000.50);
	Bank b3=new Bank (2155,"mouni",9000.50);
	Bank b4=new Bank (2166,"rohit",9000.50);
	Bank b5=new Bank (2177,"venky",9000.50);
	li.add(b1);
	li.add(b2);
	li.add(b3);
	li.add(b4);
	li.add(b5);
	
}
 String dateAndTime(){
 DateFormat d=new SimpleDateFormat("DD/MM/YY HH:mm:ss");
 Date d1=new Date();
return d.format(d1);
 }

	
	@Override
	public void save1(Bank b) {
		// TODO Auto-generated method stub
		li.add(b);
		
	}

	@Override
	public double showBal1(int amt ) {
		// TODO Auto-generated method stub
	Bank bb=new Bank();
		for(Bank b:li)
			{
			if(b.getAnum(amt)==amt){
				 bb=b;
				 break;
				}
			}
		return bb.getAmount();
	}

	@Override
	public double deposit1(int amt1, double an) {
		Bank bb=new Bank();
		Bank b=new Bank();
		
		for(Bank b1:li)
			{
			if(b1.getAnum(amt1)==amt1){
			bb=b1;
			b.l.add(dateAndTime()   +"Deposit    "+an+"  +b.getAmount()");
			break;
			}
			}
		return (bb.getAmount()+an);
		
		
	}

	@Override
	public double withdraw1(int amt2, double an1) {
		Bank bb=new Bank();
Bank b=new Bank();
		
		for(Bank b1:li)
			{
			if(b1.getAnum(amt2)==amt2){
				bb=b1;
				b.l.add(dateAndTime()   +"withdraw    "+an1+"  +b.getAmount()");
				
			
			}}
		return (bb.getAmount()-an1);
		
		// TODO Auto-generated method stub
		
	}

	

	
	@Override
	public double fund1(int amt3, int an2, int an3) {
		Bank bb1=new Bank();
		Bank bb2=new Bank();
		Bank b=new Bank();
		for(Bank b1:li)
		{
			if(b1.getAnum(amt3)==amt3){
			     bb1=b1;
			     b.l.add(dateAndTime()   +"withdraw    "+an3+"  +b.getAmount()");
			     break;
		
		       }
			
		 }
		for (Bank b2:li){
			if(b2.getAnum(an2)==an2){
				bb2=b2;
				break;
			
			}
		}
		System.out.println((bb1.getAmount()-an3));
		return (bb2.getAmount()+an3);
		
		
		// TODO Auto-generated method stub
		
	}

	

	@Override
	public List<String> printTrans(int amt4) {
		// TODO Auto-generated method stub
		Bank bb=new Bank();
		List<String> g=new ArrayList();
		for(Bank b:li)
		{
		if(b.getAnum(amt4)==amt4){
			
			 bb=b;
			 break;
			}
		}
		
		return bb.l;
	}

	

	
}

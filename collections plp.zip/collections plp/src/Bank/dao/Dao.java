package Bank.dao;

import java.util.List;

import Bank.model.Bank;

public interface Dao {

	void save1(Bank b);

	double showBal1(int amt);

	double deposit1(int amt1, double an);

	double withdraw1(int amt2, double an1);
	double  fund1(int amt3, int an2, int an3);
	

	
	List<String> printTrans(int amt4);
	
	
	
	
	
	

	
}

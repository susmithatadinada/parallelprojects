package Bank.Exception;

public class IncorrectDataException  extends Exception{

	/**
	 * if any exception this is thrown
	 */
	private static final long serialVersionUID = 1L;
	//super.msg();

}

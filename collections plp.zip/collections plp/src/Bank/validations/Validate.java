package Bank.validations;

public class Validate {
	public boolean name(String str){
		boolean n_val=str.matches("[A-Z][a-z]*");
		if(n_val)
			return true;
		
		return false;
		
		
	}
	



	public boolean num(int s) {
		// TODO Auto-generated method stub
		boolean n_val=Integer.toString(s).matches("^[2][1][0-9]{2}$");
		if(n_val)
			return true;
		return false;
		
	}




	public boolean num1(double s2) {
		// TODO Auto-generated method stub
		boolean n_val=Double.toString(s2).matches("[0-9]+(\\.){0,1}[0,9]*");
		if(n_val)
		return true;
		return false;
	}

	public boolean num2(double s3) {
		// TODO Auto-generated method stub
		boolean n_val=Double.toString(s3).matches("^[0-9]{4}$");
		if(n_val)
			return true;
		return false;

}
}

package Bank.ui;

import java.util.List;
import java.util.Scanner;

import Bank.Service.Service;
import Bank.Service.ServiceImp;

public class Main {

	public static void main(String[] args) {
		int i = 0;

		 Service service=new ServiceImp();
		 do{
		System.out.println("WELCOME TO XYZ BANK");
	 Scanner sc= new Scanner(System.in);
	 System.out.println(" ENTER YOUR CHOICE");
	 System.out.println("1.CREATE ACCOUNT\n2.SHOW BALANCE\n3.DEPOSIT\n4.WITHDRAW\n5.FIND TRANSACTIONS\n6.PRINT TANSACTIONS");
	 int choice=0;
	 choice=sc.nextInt();
	
	 switch(choice)
	 {
	 case 1 :
		 service.createAccount();
		 break;
	 case 2:
		 System.out.println("ENTER ACCOUNT NUMBER");
		 int amt=sc.nextInt(); 
		  System.out.println(service.showBal(amt));
		 break;
	 case 3:
		 System.out.println("ENTER ACCOUNT NUMBER");
		 int amt1=sc.nextInt();
		
		 System.out.println(service.deposit(amt1));
		 break;
	 case 4:
		 System.out.println("ENTER ACCOUNT NUMBER");
		 int amt2=sc.nextInt();
		 System.out.println(service.withdraw(amt2));
		 break;
	 case 5:
		 System.out.println("ENTER ACCOUNT NUMBER");
		 int amt3=sc.nextInt();
		 System.out.println(service.fundTrans(amt3));
		System.out.println("TRANSACTION DONE SUCCESSFULLY");
		 break;
	 case 6 :
		 System.out.println("ENTER ACCOUNT NUMBER");
	      int amt4=sc.nextInt();
	      List<String> d=service.printTrans(amt4);
		System.out.println(d);
		 break;
    default: System.out.println("PLEASE ENTER A VALID CHOICE");
    
    
	 }  System.out.println("1.DO YOU WANT TO CONTINUE\n2.EXIT");
	 i=sc.nextInt();
	 
	} while(i==1);
		 {}
	}

	

}

package com.cg.service;

import java.sql.SQLException;
import java.util.Map;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.exception.InsufficientFundException;

public class AccountService implements Transaction {

	AccountDAO dao = new AccountDAOImpl();

	@Override
	public double withdraw(Account ob, double amount) throws InsufficientFundException, SQLException {
		double new_balance = ob.getBalance() - amount;
		if (new_balance < 1000.0 || amount < 0) {
			new_balance = ob.getBalance();

			throw new InsufficientFundException("Insufficient fund. Can not process withdrawal", new_balance);
		}

		ob.setBalance(new_balance);
		dao.updateAccount(ob);

		return new_balance;
	}

	@Override
	public double Deposit(Account ob, double amount) throws InsufficientFundException, SQLException {
		double new_balance = ob.getBalance() + amount;
		if (amount < 0)
			try {
				{

					new_balance = ob.getBalance();
					throw new InsufficientFundException("Invalid amount to be added", amount);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		ob.setBalance(new_balance);
		dao.updateAccount(ob);

		return new_balance;
	}

	@Override
	public boolean addAccount(Account ob) {
		return dao.addAccount(ob);
	}

	@Override
	public boolean deleteAccount(Account ob) {
		return dao.deleteAccount(ob);
	}

	@Override
	public Account findAccount(Long mobileno) {
		return dao.findAccount(mobileno);
	}

	@Override
	public Map<Long, Account> getAllAccounts() throws SQLException {
		return dao.getAllAccounts();
	}

	@Override
	public boolean updateAccount(Account ob) throws SQLException {
		return dao.updateAccount(ob);
	}

	@Override
	public double TransferMoney(Account from, Account to, double amount)
			throws InsufficientFundException, SQLException {
		return dao.TransferMoney(from, to, amount);
	}
}

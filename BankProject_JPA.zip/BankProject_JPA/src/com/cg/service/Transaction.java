package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;

public interface Transaction extends AccountOperation {

	public double withdraw(Account ob, double amount) throws InsufficientFundException, SQLException;

	public double Deposit(Account ob, double amount) throws InsufficientFundException, SQLException;

	public double TransferMoney(Account from, Account to, double amount) throws InsufficientFundException, SQLException;

	public default void printStatment(Account obj) {

		System.out.println("Statement for Account No. :- " + obj.getAid());
		System.out.println("Mobile No. :- " + obj.getMobile());
		System.out.println("AccountHolder Name :- " + obj.getAccountholder());
		System.out.println("Balance is :- " + obj.getBalance());
	}

}
